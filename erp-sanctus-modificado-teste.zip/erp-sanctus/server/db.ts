import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  productionLogs,
  productionTimes,
  floorTracking,
  paintingMovements,
  paintingPayments,
  paintingPrices,
  orders,
  orderShipments,
  clients,
  materials,
  stockEntries,
  stockMovements,
  manualStockItems,
  purchaseOrders,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// PRODUCTION QUERIES
// ============================================================================

export async function getProductionTimes() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(productionTimes);
}

export async function getProductionTimeByPieceAndFunction(piece: string, func: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(productionTimes)
    .where(and(eq(productionTimes.piece, piece), eq(productionTimes.function, func)))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createProductionLog(log: typeof productionLogs.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(productionLogs).values(log);
  return result;
}

export async function getProductionLogsByUser(userId: number, startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions: any[] = [eq(productionLogs.userId, userId)];
  
  if (startDate && endDate) {
    conditions.push(gte(productionLogs.loggedAt, startDate));
    conditions.push(lte(productionLogs.loggedAt, endDate));
  }
  
  return db
    .select()
    .from(productionLogs)
    .where(and(...conditions))
    .orderBy(desc(productionLogs.loggedAt));
}

export async function getProductionLogsByDate(date: Date) {
  const db = await getDb();
  if (!db) return [];
  
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  return db
    .select()
    .from(productionLogs)
    .where(and(
      gte(productionLogs.loggedAt, startOfDay),
      lte(productionLogs.loggedAt, endOfDay)
    ))
    .orderBy(desc(productionLogs.loggedAt));
}

export async function getProductionLogsByDateRange(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(productionLogs)
    .where(and(
      gte(productionLogs.loggedAt, startDate),
      lte(productionLogs.loggedAt, endDate)
    ))
    .orderBy(desc(productionLogs.loggedAt));
}

// ============================================================================
// FLOOR TRACKING QUERIES
// ============================================================================

export async function getFloorTracking() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(floorTracking);
}

export async function getFloorTrackingByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(floorTracking).where(eq(floorTracking.code, code)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateFloorTracking(code: string, piece: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getFloorTrackingByCode(code);
  if (existing) {
    return db.update(floorTracking).set({ piece }).where(eq(floorTracking.code, code));
  }
  
  return db.insert(floorTracking).values({ code, piece });
}

export async function updateFloorTrackingStatus(code: string, stage: string, status: "pending" | "completed") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: Record<string, any> = {};
  updateData[stage] = status;
  
  return db.update(floorTracking).set(updateData).where(eq(floorTracking.code, code));
}

// ============================================================================
// PAINTING QUERIES
// ============================================================================

export async function getPaintingPrices() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paintingPrices);
}

export async function getPaintingPriceByPiece(piece: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(paintingPrices).where(eq(paintingPrices.piece, piece)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createPaintingMovement(movement: typeof paintingMovements.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(paintingMovements).values(movement);
}

export async function getPaintingMovementsByPainter(painterId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paintingMovements).where(eq(paintingMovements.painterId, painterId));
}

export async function getAllPaintingMovements() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paintingMovements);
}

export async function createPaintingPayment(payment: typeof paintingPayments.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(paintingPayments).values(payment);
}

export async function getPaintingPaymentsByPainter(painterId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paintingPayments).where(eq(paintingPayments.painterId, painterId));
}

export async function getAllPaintingPayments() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paintingPayments);
}

// ============================================================================
// ORDERS QUERIES
// ============================================================================

export async function getClients() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(clients);
}

export async function createClient(client: typeof clients.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(clients).values(client);
}

export async function getOrders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders);
}

export async function getOrdersByClient(clientId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.clientId, clientId));
}

export async function createOrder(order: typeof orders.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(orders).values(order);
}

export async function getOrderShipments(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderShipments).where(eq(orderShipments.orderId, orderId));
}

export async function createOrderShipment(shipment: typeof orderShipments.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(orderShipments).values(shipment);
}

// ============================================================================
// STOCK/MATERIALS QUERIES
// ============================================================================

export async function getMaterials() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(materials);
}

export async function getMaterialByName(name: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(materials).where(eq(materials.name, name)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getMaterialById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(materials).where(eq(materials.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createMaterial(material: typeof materials.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(materials).values(material);
}

export async function updateMaterialStock(id: number, currentStock: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(materials).set({ currentStock }).where(eq(materials.id, id));
}

export async function createStockEntry(entry: typeof stockEntries.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(stockEntries).values(entry);
}

export async function getStockEntriesByMaterial(materialId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stockEntries).where(eq(stockEntries.materialId, materialId));
}

export async function createStockMovement(movement: typeof stockMovements.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(stockMovements).values(movement);
}

export async function getStockMovementsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stockMovements).where(eq(stockMovements.userId, userId));
}

export async function getAllStockMovements() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(stockMovements);
}

export async function getManualStockItems() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(manualStockItems);
}

export async function updateManualStockItem(id: number, data: Partial<typeof manualStockItems.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(manualStockItems).set(data).where(eq(manualStockItems.id, id));
}

export async function getPurchaseOrders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(purchaseOrders);
}

export async function createPurchaseOrder(order: typeof purchaseOrders.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(purchaseOrders).values(order);
}

export async function updatePurchaseOrder(id: number, data: Partial<typeof purchaseOrders.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(purchaseOrders).set(data).where(eq(purchaseOrders.id, id));
}
