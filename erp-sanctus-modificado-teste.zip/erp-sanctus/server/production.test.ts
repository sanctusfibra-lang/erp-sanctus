import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context for authenticated admin user
function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

// Mock context for regular user
function createUserContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "regular-user",
      email: "user@example.com",
      name: "Regular User",
      loginMethod: "manus",
      role: "colaborador",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Production Module", () => {
  describe("getTimes", () => {
    it("should return production times for authenticated users", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const times = await caller.production.getTimes();

      expect(Array.isArray(times)).toBe(true);
    });
  });

  describe("logProduction", () => {
    it("should allow authenticated user to log production", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.production.logProduction({
        piece: "ANJO ADORADOR",
        function: "FUNDIÇÃO",
        size: "UNIDADE",
        weight: "2.5",
        quality: "OK",
        quantity: 1,
        code: "AA-001",
      });

      expect(result).toBeDefined();
    });

    it("should require authentication", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.production.logProduction({
          piece: "TEST",
          function: "TEST",
          size: "TEST",
          quantity: 1,
          code: "TEST",
        });
        expect.fail("Should have thrown unauthorized error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });
  });

  describe("getMyLogs", () => {
    it("should return user's own production logs", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const logs = await caller.production.getMyLogs({});

      expect(Array.isArray(logs)).toBe(true);
    });
  });
});

describe("Floor Tracking Module", () => {
  describe("getAll", () => {
    it("should require admin role", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.floorTracking.getAll();
        expect.fail("Should have thrown forbidden error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should allow admin to get all floor tracking", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const tracking = await caller.floorTracking.getAll();

      expect(Array.isArray(tracking)).toBe(true);
    });
  });

  describe("getByCode", () => {
    it("should allow authenticated user to get floor tracking by code", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      const tracking = await caller.floorTracking.getByCode({ code: "AA-001" });

      // Result can be undefined if code doesn't exist
      expect(tracking === undefined || typeof tracking === "object").toBe(true);
    });
  });
});

describe("Stock Module", () => {
  describe("logMovement", () => {
    it("should allow authenticated user to log stock movement", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      // This will fail if material doesn't exist, which is expected
      try {
        await caller.stock.logMovement({
          materialId: 999,
          quantity: 10,
        });
      } catch (error: any) {
        expect(error.code).toBe("NOT_FOUND");
      }
    });
  });

  describe("getMaterials", () => {
    it("should require admin role", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.stock.getMaterials();
        expect.fail("Should have thrown forbidden error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should allow admin to get all materials", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const materials = await caller.stock.getMaterials();

      expect(Array.isArray(materials)).toBe(true);
    });
  });
});

describe("Dashboard Module", () => {
  describe("getKPIs", () => {
    it("should require admin role", async () => {
      const ctx = createUserContext();
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.dashboard.getKPIs();
        expect.fail("Should have thrown forbidden error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });

    it("should return KPIs for admin", async () => {
      const ctx = createAdminContext();
      const caller = appRouter.createCaller(ctx);

      const kpis = await caller.dashboard.getKPIs();

      expect(kpis).toBeDefined();
      expect(typeof kpis.weeklyProductivity).toBe("number");
      expect(typeof kpis.openPaintingPieces).toBe("number");
      expect(typeof kpis.pendingOrders).toBe("number");
      expect(typeof kpis.lowStockMaterials).toBe("number");
    });
  });
});

describe("RBAC (Role-Based Access Control)", () => {
  it("should enforce admin-only procedures", async () => {
    const userCtx = createUserContext();
    const adminCtx = createAdminContext();

    const userCaller = appRouter.createCaller(userCtx);
    const adminCaller = appRouter.createCaller(adminCtx);

    // User should not access admin procedures
    try {
      await userCaller.stock.getMaterials();
      expect.fail("User should not access admin procedure");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }

    // Admin should access admin procedures
    const materials = await adminCaller.stock.getMaterials();
    expect(Array.isArray(materials)).toBe(true);
  });

  it("should allow protected procedures for authenticated users", async () => {
    const userCtx = createUserContext();
    const caller = appRouter.createCaller(userCtx);

    // User should access protected procedures
    const logs = await caller.production.getMyLogs({});
    expect(Array.isArray(logs)).toBe(true);
  });
});
