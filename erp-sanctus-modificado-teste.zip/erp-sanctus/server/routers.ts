import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============================================================================
  // PRODUCTION (SANCTUS 3.0) ROUTERS
  // ============================================================================
  production: router({
    // Get all production times (public for all authenticated users)
    getTimes: protectedProcedure.query(() => db.getProductionTimes()),

    // Create production time entry (admin only)
    createTime: adminProcedure
      .input(
        z.object({
          piece: z.string().min(1),
          function: z.string().min(1),
          size: z.string().min(1),
          timeMinutes: z.number().positive(),
        })
      )
      .mutation(async ({ input }) => {
        const dbInstance = await db.getDb();
        if (!dbInstance) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
        
        const { productionTimes } = require("../drizzle/schema");
        return dbInstance.insert(productionTimes).values(input);
      }),

    // Log production (only for own user or admin)
    logProduction: protectedProcedure
      .input(
        z.object({
          piece: z.string().min(1),
          function: z.string().min(1),
          size: z.string().min(1),
          weight: z.string().optional(),
          quality: z.string().optional(),
          quantity: z.number().positive().default(1),
          code: z.string().min(1),
          timeSpent: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return db.createProductionLog({
          userId: ctx.user.id,
          ...input,
          loggedAt: new Date(),
        });
      }),

    // Get production logs for current user
    getMyLogs: protectedProcedure
      .input(
        z.object({
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        })
      )
      .query(({ input, ctx }) => {
        return db.getProductionLogsByUser(ctx.user.id, input.startDate, input.endDate);
      }),

    // Get production logs for a specific user (admin only)
    getLogsByUser: adminProcedure
      .input(
        z.object({
          userId: z.number(),
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        })
      )
      .query(({ input }) => {
        return db.getProductionLogsByUser(input.userId, input.startDate, input.endDate);
      }),

    // Get production logs by date (admin only)
    getLogsByDate: adminProcedure
      .input(z.object({ date: z.date() }))
      .query(({ input }) => db.getProductionLogsByDate(input.date)),
  }),

  // ============================================================================
  // FLOOR TRACKING (CHÃO) ROUTERS
  // ============================================================================
  floorTracking: router({
    // Get all floor tracking (admin only)
    getAll: adminProcedure.query(() => db.getFloorTracking()),

    // Get floor tracking by code (public for authenticated)
    getByCode: protectedProcedure
      .input(z.object({ code: z.string().min(1) }))
      .query(({ input }) => db.getFloorTrackingByCode(input.code)),

    // Create or update floor tracking (admin only)
    createOrUpdate: adminProcedure
      .input(
        z.object({
          code: z.string().min(1),
          piece: z.string().min(1),
        })
      )
      .mutation(({ input }) => db.createOrUpdateFloorTracking(input.code, input.piece)),

    // Update stage status (admin only)
    updateStageStatus: adminProcedure
      .input(
        z.object({
          code: z.string().min(1),
          stage: z.enum(["foundry", "cleaning", "finishing", "mantle", "sprayPainting"]),
          status: z.enum(["pending", "completed"]),
        })
      )
      .mutation(({ input }) => db.updateFloorTrackingStatus(input.code, input.stage, input.status)),
  }),

  // ============================================================================
  // PAINTING (TERCEIRIZAÇÃO) ROUTERS
  // ============================================================================
  painting: router({
    // Get painting prices (public for authenticated)
    getPrices: protectedProcedure.query(() => db.getPaintingPrices()),

    // Get price by piece
    getPriceByPiece: protectedProcedure
      .input(z.object({ piece: z.string().min(1) }))
      .query(({ input }) => db.getPaintingPriceByPiece(input.piece)),

    // Log painting movement (admin only)
    logMovement: adminProcedure
      .input(
        z.object({
          painterId: z.number().positive(),
          piece: z.string().min(1),
          quantity: z.number().positive(),
          type: z.enum(["entrada", "saida"]),
          email: z.string().email().optional(),
        })
      )
      .mutation(({ input }) => db.createPaintingMovement(input)),

    // Get movements by painter (admin only)
    getMovementsByPainter: adminProcedure
      .input(z.object({ painterId: z.number().positive() }))
      .query(({ input }) => db.getPaintingMovementsByPainter(input.painterId)),

    // Log payment (admin only)
    logPayment: adminProcedure
      .input(
        z.object({
          painterId: z.number().positive(),
          amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
        })
      )
      .mutation(({ input }) => db.createPaintingPayment(input)),

    // Get payments by painter (admin only)
    getPaymentsByPainter: adminProcedure
      .input(z.object({ painterId: z.number().positive() }))
      .query(({ input }) => db.getPaintingPaymentsByPainter(input.painterId)),
  }),

  // ============================================================================
  // ORDERS ROUTERS
  // ============================================================================
  orders: router({
    // Get all clients (admin only)
    getClients: adminProcedure.query(() => db.getClients()),

    // Create client (admin only)
    createClient: adminProcedure
      .input(
        z.object({
          name: z.string().min(1),
          email: z.string().email().optional(),
          phone: z.string().optional(),
        })
      )
      .mutation(({ input }) => db.createClient(input)),

    // Get all orders (admin only)
    getAll: adminProcedure.query(() => db.getOrders()),

    // Get orders by client (admin only)
    getByClient: adminProcedure
      .input(z.object({ clientId: z.number().positive() }))
      .query(({ input }) => db.getOrdersByClient(input.clientId)),

    // Create order (admin only)
    create: adminProcedure
      .input(
        z.object({
          clientId: z.number().positive(),
          description: z.string().min(1),
          quantity: z.number().positive(),
        })
      )
      .mutation(({ input }) => db.createOrder(input)),

    // Get shipments for order (admin only)
    getShipments: adminProcedure
      .input(z.object({ orderId: z.number().positive() }))
      .query(({ input }) => db.getOrderShipments(input.orderId)),

    // Create shipment with NF (admin only)
    createShipment: adminProcedure
      .input(
        z.object({
          orderId: z.number().positive(),
          nf: z.string().min(1),
          quantityShipped: z.number().positive(),
        })
      )
      .mutation(async ({ input }) => {
        // Create shipment
        const shipmentResult = await db.createOrderShipment(input);
        
        // TODO: Update order status based on total shipped vs quantity
        // This requires fetching the order and all its shipments to calculate remaining quantity
        
        return shipmentResult;
      }),
  }),

  // ============================================================================
  // STOCK/MATERIALS ROUTERS
  // ============================================================================
  stock: router({
    // Get all materials (admin only)
    getMaterials: adminProcedure.query(() => db.getMaterials()),

    // Create material (admin only)
    createMaterial: adminProcedure
      .input(
        z.object({
          name: z.string().min(1),
          category: z.string().min(1),
          minimumStock: z.number().default(0),
          trackable: z.boolean().default(true),
        })
      )
      .mutation(({ input }) => db.createMaterial(input)),

    // Log stock entry (admin only)
    logEntry: adminProcedure
      .input(
        z.object({
          materialId: z.number().positive(),
          quantity: z.number().positive(),
        })
      )
      .mutation(async ({ input }) => {
        // Create entry
        await db.createStockEntry(input);
        
        // Update material current stock
        const material = await db.getMaterialById(input.materialId);
        if (material) {
          await db.updateMaterialStock(input.materialId, material.currentStock + input.quantity);
        }
      }),

    // Get entries by material (admin only)
    getEntriesByMaterial: adminProcedure
      .input(z.object({ materialId: z.number().positive() }))
      .query(({ input }) => db.getStockEntriesByMaterial(input.materialId)),

    // Log stock movement/retirada (protectedProcedure - any user can log their own)
    logMovement: protectedProcedure
      .input(
        z.object({
          materialId: z.number().positive(),
          quantity: z.number().positive(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Verify material exists
        const material = await db.getMaterialById(input.materialId);
        if (!material) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Material not found" });
        }

        // Create movement
        await db.createStockMovement({
          materialId: input.materialId,
          userId: ctx.user.id,
          quantity: input.quantity,
          movementDate: new Date(),
        });

        // Update material current stock
        const newStock = Math.max(0, material.currentStock - input.quantity);
        await db.updateMaterialStock(input.materialId, newStock);
      }),

    // Get movements by user (own data only)
    getMyMovements: protectedProcedure.query(({ ctx }) => {
      return db.getStockMovementsByUser(ctx.user.id);
    }),

    // Get all movements (admin only)
    getAllMovements: adminProcedure.query(() => db.getAllStockMovements()),

    // Get manual stock items (admin only)
    getManualItems: adminProcedure.query(() => db.getManualStockItems()),

    // Update manual stock item (admin only)
    updateManualItem: adminProcedure
      .input(
        z.object({
          id: z.number().positive(),
          currentStock: z.number().optional(),
        })
      )
      .mutation(({ input }) => {
        return db.updateManualStockItem(input.id, { currentStock: input.currentStock });
      }),

    // Get purchase orders (admin only)
    getPurchaseOrders: adminProcedure.query(() => db.getPurchaseOrders()),

    // Create purchase order (admin only)
    createPurchaseOrder: adminProcedure
      .input(
        z.object({
          category: z.string().min(1),
          itemName: z.string().min(1),
          quantityToPurchase: z.number().positive(),
        })
      )
      .mutation(({ input }) => {
        return db.createPurchaseOrder({
          ...input,
          generatedAt: new Date(),
        });
      }),

    // Update purchase order status (admin only)
    updatePurchaseOrderStatus: adminProcedure
      .input(
        z.object({
          id: z.number().positive(),
          status: z.enum(["pendente", "pedido", "recebido"]),
        })
      )
      .mutation(({ input }) => {
        return db.updatePurchaseOrder(input.id, { status: input.status });
      }),
  }),

  // ============================================================================
  // DASHBOARD ROUTERS
  // ============================================================================
  dashboard: router({
    // Get KPIs (admin only)
    getKPIs: adminProcedure.query(async () => {
      const productionLogs = await db.getProductionLogsByDate(new Date());
      const paintingMovements = await db.getAllPaintingMovements();
      const orders = await db.getOrders();
      const materials = await db.getMaterials();

      // Calculate weekly productivity (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const weeklyLogs = await db.getProductionLogsByDateRange(sevenDaysAgo, new Date());

      // Count open painting pieces (entrada - saida)
      const paintingBalance = paintingMovements.reduce((acc, mov) => {
        return acc + (mov.type === "entrada" ? mov.quantity : -mov.quantity);
      }, 0);

      // Count pending orders
      const pendingOrders = orders.filter(o => o.status !== "entregue").length;

      // Count low stock materials
      const lowStockMaterials = materials.filter(m => m.currentStock <= m.minimumStock && m.trackable).length;

      // Calculate average productivity (total quantity / total logs)
      const weeklyProductivity = weeklyLogs.length > 0
        ? Math.round((weeklyLogs.reduce((sum, log) => sum + log.quantity, 0) / weeklyLogs.length) * 10)
        : 0;

      return {
        weeklyProductivity,
        openPaintingPieces: Math.max(0, paintingBalance),
        pendingOrders,
        lowStockMaterials,
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
