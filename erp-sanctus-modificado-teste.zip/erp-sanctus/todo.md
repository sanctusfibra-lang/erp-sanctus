# ERP Sanctus - TODO

## Fase 1: Estrutura Base e Banco de Dados
- [x] Criar schema de banco de dados completo (usuários, produção, pintura, pedidos, compras)
- [x] Implementar modelos Drizzle para todos os módulos
- [x] Configurar autenticação com roles (admin/colaborador)
- [x] Criar helpers de banco de dados para queries

## Fase 2: Módulo Sanctus 3.0 (Produção)
- [x] Formulário de lançamento de produção (peça, função, tamanho, peso, qualidade, quantidade, código)
- [x] Tabela de tempos por função e peça
- [x] Dashboard de produtividade diária com cálculos corretos
- [x] Dashboard de produtividade semanal com cálculos corretos
- [x] Dashboard de produtividade mensal com cálculos corretos
- [x] Cálculo automático de disponível (8h/dia * 5 dias/semana)
- [x] Cálculo automático de produtividade baseada em tempos/meta
- [ ] Vincular logProduction à atualização automática do Chão

## Fase 3: Rastreamento de Peças (Chão)
- [x] Mapa visual de peças por código e nome
- [x] Células coloridas por etapa (Fundição, Limpeza, Acabamento, Manto, Pintura Pistola)
- [x] Atualização de status conforme produção avança
- [x] Visualização em grid/tabela

## Fase 4: Módulo Terceirização Pintura
- [x] Formulário de entrada/saída de peças por pintor
- [x] Controle de saldo de peças (entrega, retirada, saldo) - consulta consolidada
- [x] Controle financeiro (valor em aberto, saldo a pagar) - cálculos
- [x] Tabela de preços por peça
- [x] Dashboard de pintura por colaborador com resumo completo

## Fase 5: Módulo Pedidos
- [x] Cadastro de pedidos por cliente
- [ ] Visão consolidada de pedidos integrados com totais e saldos
- [x] Controle de envios com NF
- [ ] Subtração automática de quantidades enviadas (remover TODO)
- [ ] Rastreamento de pendências com atualização automática

## Fase 6: Módulo Compras/Estoque
- [x] Formulário de entradas de material
- [x] Formulário de movimentações (retiradas)
- [x] Base de estoque com cálculo automático
- [ ] Lista manual de itens sem rastreamento - fluxo completo/UI
- [ ] Geração automática de lista de pedido baseada em mínimo + manual
- [x] Histórico por colaborador

## Fase 7: Perfis de Colaboradores
- [x] Página de perfil individual
- [x] Histórico de lançamentos de produção (Sanctus)
- [x] Histórico de retiradas de material (Compras)
- [x] Acesso restrito aos próprios dados

## Fase 8: Dashboard Geral e KPIs
- [x] Dashboard com KPIs consolidados (estrutura base)
- [x] Produtividade da semana (cálculos)
- [x] Peças em aberto na pintura (cálculos)
- [x] Pedidos pendentes (cálculos)
- [x] Materiais abaixo do estoque mínimo (implementado)
- [x] Navegação entre módulos

## Fase 9: Design e Refinamento Visual
- [x] Aplicar design system elegante e sofisticado (Tailwind 4 + shadcn/ui)
- [x] Tipografia refinada
- [x] Espaçamentos generosos
- [x] Componentes bem proporcionados
- [x] Experiência fluida em todos os ecrãs
- [ ] Testes de responsividade completos

## Fase 10: Testes e Entrega
- [x] Testes unitários (vitest)
- [ ] Testes de integração reais dos fluxos
- [ ] Validação de fluxos críticos end-to-end
- [ ] Profiling e otimização de performance
- [x] Estrutura pronta para entrega

## Gaps Identificados para Próxima Iteração
- [ ] Implementar dashboards específicos de produção (diário/semanal/mensal)
- [ ] Criar cálculos corretos de disponível e produtividade por colaborador
- [ ] Integração automática entre lançamento de produção e atualização do Chão
- [ ] Consultas consolidadas para pintura (saldo, financeiro, dashboard por colaborador)
- [ ] Remover TODO de createShipment e implementar recálculo automático de pedidos
- [ ] Geração automática de lista de compras
- [ ] Testes de integração e responsividade
