CREATE TABLE `clients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `floor_tracking` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(100) NOT NULL,
	`piece` varchar(255) NOT NULL,
	`foundry` enum('pending','completed') NOT NULL DEFAULT 'pending',
	`cleaning` enum('pending','completed') NOT NULL DEFAULT 'pending',
	`finishing` enum('pending','completed') NOT NULL DEFAULT 'pending',
	`mantle` enum('pending','completed') NOT NULL DEFAULT 'pending',
	`spray_painting` enum('pending','completed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `floor_tracking_id` PRIMARY KEY(`id`),
	CONSTRAINT `floor_tracking_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `manual_stock_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(100) NOT NULL,
	`minimum_stock` int NOT NULL DEFAULT 0,
	`current_stock` int NOT NULL DEFAULT 0,
	`last_updated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `manual_stock_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `manual_stock_items_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `materials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(100) NOT NULL,
	`minimum_stock` int NOT NULL DEFAULT 0,
	`current_stock` int NOT NULL DEFAULT 0,
	`trackable` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `materials_id` PRIMARY KEY(`id`),
	CONSTRAINT `materials_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `order_shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`order_id` int NOT NULL,
	`nf` varchar(50) NOT NULL,
	`quantity_shipped` int NOT NULL,
	`shipment_date` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `order_shipments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`client_id` int NOT NULL,
	`description` varchar(500) NOT NULL,
	`quantity` int NOT NULL,
	`status` enum('aberto','parcial','entregue') NOT NULL DEFAULT 'aberto',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `painting_movements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`painter_id` int NOT NULL,
	`piece` varchar(255) NOT NULL,
	`quantity` int NOT NULL,
	`type` enum('entrada','saida') NOT NULL,
	`email` varchar(320),
	`logged_at` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `painting_movements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `painting_payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`painter_id` int NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`logged_at` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `painting_payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `painting_prices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`piece` varchar(255) NOT NULL,
	`price` decimal(10,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `painting_prices_id` PRIMARY KEY(`id`),
	CONSTRAINT `painting_prices_piece_unique` UNIQUE(`piece`)
);
--> statement-breakpoint
CREATE TABLE `production_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`piece` varchar(255) NOT NULL,
	`function` varchar(100) NOT NULL,
	`size` varchar(50) NOT NULL,
	`weight` decimal(10,2),
	`quality` varchar(50),
	`quantity` int NOT NULL DEFAULT 1,
	`code` varchar(100) NOT NULL,
	`time_spent` int,
	`logged_at` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `production_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `production_times` (
	`id` int AUTO_INCREMENT NOT NULL,
	`piece` varchar(255) NOT NULL,
	`function` varchar(100) NOT NULL,
	`size` varchar(50) NOT NULL,
	`time_minutes` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `production_times_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchase_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`category` varchar(100) NOT NULL,
	`item_name` varchar(255) NOT NULL,
	`quantity_to_purchase` int NOT NULL,
	`status` enum('pendente','pedido','recebido') NOT NULL DEFAULT 'pendente',
	`generated_at` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `purchase_orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`material_id` int NOT NULL,
	`quantity` int NOT NULL,
	`entry_date` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stock_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stock_movements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`material_id` int NOT NULL,
	`user_id` int NOT NULL,
	`quantity` int NOT NULL,
	`movement_date` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `stock_movements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','colaborador') NOT NULL DEFAULT 'colaborador';