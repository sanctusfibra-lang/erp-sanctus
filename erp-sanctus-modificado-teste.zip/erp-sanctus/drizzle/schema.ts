import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "colaborador"]).default("colaborador").notNull(),
  isThirdParty: boolean("is_third_party").default(false).notNull(), // Se é terceirizado (pintor)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============================================================================
// MÓDULO CADASTROS - CLIENTES E PEÇAS
// ============================================================================

/**
 * Clientes cadastrados
 */
export const clients = mysqlTable("clients", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Client = typeof clients.$inferSelect;
export type InsertClient = typeof clients.$inferInsert;

/**
 * Tabela de peças cadastradas
 * Cadastro centralizado de todas as peças produzidas
 */
export const pieces = mysqlTable("pieces", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(), // Nome da peça (ex: "ANJO ADORADOR")
  cost: decimal("cost", { precision: 10, scale: 2 }).default("0"), // Custo de produção
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Piece = typeof pieces.$inferSelect;
export type InsertPiece = typeof pieces.$inferInsert;

// ============================================================================
// MÓDULO SANCTUS 3.0 - PRODUÇÃO
// ============================================================================

/**
 * Tabela de tempos por função e peça
 * Define quanto tempo leva para executar cada função em cada peça
 */
export const productionTimes = mysqlTable("production_times", {
  id: int("id").autoincrement().primaryKey(),
  pieceId: int("piece_id").notNull(), // Referência à peça
  function: varchar("function", { length: 100 }).notNull(), // Função (Fundição, Limpeza, Acabamento, Manto, Pintura Pistola)
  timeMinutes: int("time_minutes").notNull(), // Tempo em minutos
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProductionTime = typeof productionTimes.$inferSelect;
export type InsertProductionTime = typeof productionTimes.$inferInsert;

/**
 * Lançamentos de produção diários
 * Registra cada produção realizada por um colaborador
 */
export const productionLogs = mysqlTable("production_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(), // Colaborador que realizou
  pieceId: int("piece_id").notNull(), // Referência à peça
  function: varchar("function", { length: 100 }).notNull(),
  weight: decimal("weight", { precision: 10, scale: 2 }),
  quality: varchar("quality", { length: 50 }), // Qualidade (ex: "OK", "Retrabalho")
  quantity: int("quantity").notNull().default(1),
  code: varchar("code", { length: 100 }).notNull(), // Código único da peça
  timeSpent: int("time_spent"), // Tempo gasto em minutos
  loggedAt: timestamp("logged_at").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProductionLog = typeof productionLogs.$inferSelect;
export type InsertProductionLog = typeof productionLogs.$inferInsert;

/**
 * Rastreamento de peças no chão de fábrica
 * Mapeia em qual etapa cada peça se encontra
 */
export const floorTracking = mysqlTable("floor_tracking", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 100 }).notNull().unique(),
  pieceId: int("piece_id").notNull(), // Referência à peça
  foundry: mysqlEnum("foundry", ["pending", "completed"]).default("pending").notNull(),
  cleaning: mysqlEnum("cleaning", ["pending", "completed"]).default("pending").notNull(),
  finishing: mysqlEnum("finishing", ["pending", "completed"]).default("pending").notNull(),
  mantle: mysqlEnum("mantle", ["pending", "completed"]).default("pending").notNull(),
  sprayPainting: mysqlEnum("spray_painting", ["pending", "completed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FloorTracking = typeof floorTracking.$inferSelect;
export type InsertFloorTracking = typeof floorTracking.$inferInsert;

// ============================================================================
// MÓDULO TERCEIRIZAÇÃO PINTURA
// ============================================================================

/**
 * Tabela de preços de pintura por peça
 */
export const paintingPrices = mysqlTable("painting_prices", {
  id: int("id").autoincrement().primaryKey(),
  pieceId: int("piece_id").notNull(), // Referência à peça
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PaintingPrice = typeof paintingPrices.$inferSelect;
export type InsertPaintingPrice = typeof paintingPrices.$inferInsert;

/**
 * Movimentações de peças para pintura (entrada/saída)
 */
export const paintingMovements = mysqlTable("painting_movements", {
  id: int("id").autoincrement().primaryKey(),
  painterId: int("painter_id").notNull(), // Pintor terceirizado
  pieceId: int("piece_id").notNull(), // Referência à peça
  quantity: int("quantity").notNull(),
  type: mysqlEnum("type", ["retirada", "devolucao"]).notNull(), // Retirada ou Devolução
  loggedAt: timestamp("logged_at").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PaintingMovement = typeof paintingMovements.$inferSelect;
export type InsertPaintingMovement = typeof paintingMovements.$inferInsert;

/**
 * Pagamentos para pintores terceirizados
 */
export const paintingPayments = mysqlTable("painting_payments", {
  id: int("id").autoincrement().primaryKey(),
  painterId: int("painter_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  loggedAt: timestamp("logged_at").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PaintingPayment = typeof paintingPayments.$inferSelect;
export type InsertPaintingPayment = typeof paintingPayments.$inferInsert;

// ============================================================================
// MÓDULO PEDIDOS
// ============================================================================

/**
 * Pedidos por cliente
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  clientId: int("client_id").notNull(),
  status: mysqlEnum("status", ["aberto", "parcial", "entregue"]).default("aberto").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Itens de pedido (múltiplas peças por pedido)
 */
export const orderItems = mysqlTable("order_items", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("order_id").notNull(),
  pieceId: int("piece_id").notNull(),
  quantity: int("quantity").notNull(),
  quantityShipped: int("quantity_shipped").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;

/**
 * Envios de pedidos com rastreamento de NF
 */
export const orderShipments = mysqlTable("order_shipments", {
  id: int("id").autoincrement().primaryKey(),
  orderItemId: int("order_item_id").notNull(),
  nf: varchar("nf", { length: 50 }).notNull(), // Número da Nota Fiscal
  quantityShipped: int("quantity_shipped").notNull(),
  shipmentDate: timestamp("shipment_date").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OrderShipment = typeof orderShipments.$inferSelect;
export type InsertOrderShipment = typeof orderShipments.$inferInsert;

// ============================================================================
// MÓDULO COMPRAS/ESTOQUE
// ============================================================================

/**
 * Materiais cadastrados
 */
export const materials = mysqlTable("materials", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  category: mysqlEnum("category", ["insumo", "producao", "adm", "3d"]).notNull(),
  minimumStock: int("minimum_stock").notNull().default(0),
  currentStock: int("current_stock").notNull().default(0),
  trackable: boolean("trackable").default(true).notNull(), // Se permite rastreamento de movimentação
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Material = typeof materials.$inferSelect;
export type InsertMaterial = typeof materials.$inferInsert;

/**
 * Entradas de material (compras)
 */
export const stockEntries = mysqlTable("stock_entries", {
  id: int("id").autoincrement().primaryKey(),
  materialId: int("material_id").notNull(),
  quantity: int("quantity").notNull(),
  entryDate: timestamp("entry_date").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StockEntry = typeof stockEntries.$inferSelect;
export type InsertStockEntry = typeof stockEntries.$inferInsert;

/**
 * Movimentações de material (retiradas por colaborador)
 */
export const stockMovements = mysqlTable("stock_movements", {
  id: int("id").autoincrement().primaryKey(),
  materialId: int("material_id").notNull(),
  userId: int("user_id").notNull(), // Colaborador que retirou
  quantity: int("quantity").notNull(),
  movementDate: timestamp("movement_date").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StockMovement = typeof stockMovements.$inferSelect;
export type InsertStockMovement = typeof stockMovements.$inferInsert;

/**
 * Itens sem rastreamento automático (lista manual)
 */
export const manualStockItems = mysqlTable("manual_stock_items", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  category: mysqlEnum("category", ["insumo", "producao", "adm", "3d"]).notNull(),
  minimumStock: int("minimum_stock").notNull().default(0),
  currentStock: int("current_stock").notNull().default(0),
  lastUpdated: timestamp("last_updated").defaultNow().onUpdateNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ManualStockItem = typeof manualStockItems.$inferSelect;
export type InsertManualStockItem = typeof manualStockItems.$inferInsert;

/**
 * Lista de compras gerada automaticamente
 */
export const purchaseOrders = mysqlTable("purchase_orders", {
  id: int("id").autoincrement().primaryKey(),
  category: mysqlEnum("category", ["insumo", "producao", "adm", "3d"]).notNull(),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  quantityToPurchase: int("quantity_to_purchase").notNull(),
  status: mysqlEnum("status", ["pendente", "pedido", "recebido"]).default("pendente").notNull(),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PurchaseOrder = typeof purchaseOrders.$inferSelect;
export type InsertPurchaseOrder = typeof purchaseOrders.$inferInsert;
