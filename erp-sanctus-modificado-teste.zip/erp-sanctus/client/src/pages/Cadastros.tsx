
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Cadastros() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Cadastros</h1>
        <p className="text-muted-foreground">
          Central de clientes, peças e colaboradores
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

        <Card>
          <CardHeader>
            <CardTitle>Clientes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <input className="w-full border rounded p-2" placeholder="Nome cliente" />
            <input className="w-full border rounded p-2" placeholder="Cidade" />
            <button className="w-full bg-black text-white rounded p-2">
              Salvar Cliente
            </button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Peças</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <input className="w-full border rounded p-2" placeholder="Nome peça" />
            <input className="w-full border rounded p-2" placeholder="Código" />
            <input className="w-full border rounded p-2" placeholder="Valor venda" />
            <button className="w-full bg-black text-white rounded p-2">
              Salvar Peça
            </button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Colaboradores</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <input className="w-full border rounded p-2" placeholder="Nome colaborador" />
            <select className="w-full border rounded p-2">
              <option>Interno</option>
              <option>Terceirizado</option>
            </select>
            <button className="w-full bg-black text-white rounded p-2">
              Salvar Colaborador
            </button>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
