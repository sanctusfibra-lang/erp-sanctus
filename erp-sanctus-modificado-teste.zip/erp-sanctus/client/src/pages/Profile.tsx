import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { User, Calendar, Package } from "lucide-react";

export default function Profile() {
  const { user } = useAuth();

  // Fetch user's data
  const { data: productionLogs = [] } = trpc.production.getMyLogs.useQuery({});
  const { data: stockMovements = [] } = trpc.stock.getMyMovements.useQuery();
  const { data: materials = [] } = trpc.stock.getMaterials.useQuery();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Meu Perfil</h1>
        <p className="text-slate-600">Informações pessoais e histórico</p>
      </div>

      {/* User Info Card */}
      <Card>
        <CardHeader>
          <CardTitle>Informações Pessoais</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-2xl font-bold">
                {user?.name?.charAt(0).toUpperCase() || "U"}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-900">{user?.name || "Usuário"}</h2>
                <p className="text-slate-600">{user?.email || "Email não disponível"}</p>
                <p className="text-sm text-slate-500 mt-2">
                  Função: <span className="font-semibold capitalize">{user?.role || "Colaborador"}</span>
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-slate-200">
              <div>
                <p className="text-sm text-slate-600 mb-1">Membro desde</p>
                <p className="font-semibold text-slate-900">
                  {user?.createdAt ? new Date(user.createdAt).toLocaleDateString("pt-BR") : "N/A"}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Último acesso</p>
                <p className="font-semibold text-slate-900">
                  {user?.lastSignedIn ? new Date(user.lastSignedIn).toLocaleDateString("pt-BR") : "N/A"}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Método de login</p>
                <p className="font-semibold text-slate-900 capitalize">{user?.loginMethod || "N/A"}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs for History */}
      <Tabs defaultValue="production" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="production">Histórico de Produção</TabsTrigger>
          <TabsTrigger value="materials">Histórico de Retiradas</TabsTrigger>
        </TabsList>

        {/* Produção Tab */}
        <TabsContent value="production" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Meu Histórico de Produção</CardTitle>
              <CardDescription>Todas as produções que você registrou</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Peça</TableHead>
                      <TableHead>Função</TableHead>
                      <TableHead>Tamanho</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                      <TableHead>Qualidade</TableHead>
                      <TableHead>Código</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {productionLogs.length > 0 ? (
                      productionLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="text-sm">
                            {new Date(log.loggedAt).toLocaleDateString("pt-BR")}
                          </TableCell>
                          <TableCell className="font-medium">{log.piece}</TableCell>
                          <TableCell>{log.function}</TableCell>
                          <TableCell>{log.size}</TableCell>
                          <TableCell className="text-right">{log.quantity}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              log.quality === "OK" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                            }`}>
                              {log.quality}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm">{log.code}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-slate-400 py-8">
                          <div className="flex flex-col items-center gap-2">
                            <Package className="w-8 h-8 opacity-50" />
                            <p>Nenhuma produção registrada</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Production Stats */}
              {productionLogs.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-200">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Total de lançamentos</p>
                    <p className="text-2xl font-bold text-slate-900">{productionLogs.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Total produzido</p>
                    <p className="text-2xl font-bold text-slate-900">
                      {productionLogs.reduce((sum, log) => sum + log.quantity, 0)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Taxa de qualidade</p>
                    <p className="text-2xl font-bold text-slate-900">
                      {(
                        (productionLogs.filter((log) => log.quality === "OK").length /
                          productionLogs.length) *
                        100
                      ).toFixed(1)}
                      %
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Retiradas Tab */}
        <TabsContent value="materials" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Meu Histórico de Retiradas</CardTitle>
              <CardDescription>Materiais que você retirou do estoque</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Material</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {stockMovements.length > 0 ? (
                      stockMovements.map((mov) => (
                        <TableRow key={mov.id}>
                          <TableCell className="text-sm">
                            {new Date(mov.movementDate).toLocaleDateString("pt-BR")}
                          </TableCell>
                          <TableCell className="font-medium">
                            {materials.find((m) => m.id === mov.materialId)?.name || "Material desconhecido"}
                          </TableCell>
                          <TableCell className="text-right">{mov.quantity}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-slate-400 py-8">
                          <div className="flex flex-col items-center gap-2">
                            <Package className="w-8 h-8 opacity-50" />
                            <p>Nenhuma retirada registrada</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Movement Stats */}
              {stockMovements.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 pt-6 border-t border-slate-200">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Total de retiradas</p>
                    <p className="text-2xl font-bold text-slate-900">{stockMovements.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Quantidade total retirada</p>
                    <p className="text-2xl font-bold text-slate-900">
                      {stockMovements.reduce((sum, mov) => sum + mov.quantity, 0)} un.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
