import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus } from "lucide-react";

export default function Painting() {
  const [activeTab, setActiveTab] = useState("movements");
  const [formData, setFormData] = useState({
    painterId: "",
    piece: "",
    quantity: "",
    type: "entrada" as "entrada" | "saida",
    email: "",
  });

  const [paymentForm, setPaymentForm] = useState({
    painterId: "",
    amount: "",
  });

  // Fetch data
  const { data: paintingPrices = [] } = trpc.painting.getPrices.useQuery();
  const { data: movements = [] } = trpc.painting.getMovementsByPainter.useQuery(
    { painterId: formData.painterId ? parseInt(formData.painterId) : 0 },
    { enabled: !!formData.painterId }
  );

  // Mutations
  const logMovementMutation = trpc.painting.logMovement.useMutation({
    onSuccess: () => {
      toast.success("Movimentação registrada!");
      setFormData({
        painterId: "",
        piece: "",
        quantity: "",
        type: "entrada",
        email: "",
      });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const logPaymentMutation = trpc.painting.logPayment.useMutation({
    onSuccess: () => {
      toast.success("Pagamento registrado!");
      setPaymentForm({ painterId: "", amount: "" });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleMovementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.painterId || !formData.piece || !formData.quantity) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    logMovementMutation.mutate({
      painterId: parseInt(formData.painterId),
      piece: formData.piece,
      quantity: parseInt(formData.quantity),
      type: formData.type,
      email: formData.email || undefined,
    });
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentForm.painterId || !paymentForm.amount) {
      toast.error("Preencha todos os campos");
      return;
    }

    logPaymentMutation.mutate({
      painterId: parseInt(paymentForm.painterId),
      amount: paymentForm.amount,
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Terceirização - Pintura</h1>
        <p className="text-slate-600">Gestão de pintura e controle financeiro</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="movements">Movimentações</TabsTrigger>
          <TabsTrigger value="payments">Pagamentos</TabsTrigger>
          <TabsTrigger value="prices">Tabela de Preços</TabsTrigger>
        </TabsList>

        {/* Movimentações Tab */}
        <TabsContent value="movements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Registrar Movimentação</CardTitle>
              <CardDescription>Entrada ou saída de peças</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleMovementSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Pintor */}
                  <div className="space-y-2">
                    <Label htmlFor="painterId">Pintor *</Label>
                    <Input
                      id="painterId"
                      type="number"
                      placeholder="ID do pintor"
                      value={formData.painterId}
                      onChange={(e) => setFormData((prev) => ({ ...prev, painterId: e.target.value }))}
                      required
                    />
                  </div>

                  {/* Tipo */}
                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo *</Label>
                    <Select value={formData.type} onValueChange={(value: any) => setFormData((prev) => ({ ...prev, type: value }))}>
                      <SelectTrigger id="type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="entrada">Entrada</SelectItem>
                        <SelectItem value="saida">Saída</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Peça */}
                  <div className="space-y-2">
                    <Label htmlFor="piece">Peça *</Label>
                    <Input
                      id="piece"
                      placeholder="Nome da peça"
                      value={formData.piece}
                      onChange={(e) => setFormData((prev) => ({ ...prev, piece: e.target.value }))}
                      required
                    />
                  </div>

                  {/* Quantidade */}
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantidade *</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      placeholder="0"
                      value={formData.quantity}
                      onChange={(e) => setFormData((prev) => ({ ...prev, quantity: e.target.value }))}
                      required
                    />
                  </div>

                  {/* Email */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="email">Email (opcional)</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="email@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={logMovementMutation.isPending}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {logMovementMutation.isPending ? "Registrando..." : "Registrar Movimentação"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Histórico de Movimentações */}
          {formData.painterId && (
            <Card>
              <CardHeader>
                <CardTitle>Histórico - Pintor {formData.painterId}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Peça</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Tipo</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {movements.length > 0 ? (
                        movements.map((mov) => (
                          <TableRow key={mov.id}>
                            <TableCell className="text-sm">
                              {new Date(mov.loggedAt).toLocaleDateString("pt-BR")}
                            </TableCell>
                            <TableCell>{mov.piece}</TableCell>
                            <TableCell>{mov.quantity}</TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded text-xs font-medium ${
                                mov.type === "entrada" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                              }`}>
                                {mov.type === "entrada" ? "Entrada" : "Saída"}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-slate-400 py-8">
                            Nenhuma movimentação registrada
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Pagamentos Tab */}
        <TabsContent value="payments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Registrar Pagamento</CardTitle>
              <CardDescription>Registre pagamentos aos pintores</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePaymentSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Pintor */}
                  <div className="space-y-2">
                    <Label htmlFor="paymentPainterId">Pintor *</Label>
                    <Input
                      id="paymentPainterId"
                      type="number"
                      placeholder="ID do pintor"
                      value={paymentForm.painterId}
                      onChange={(e) => setPaymentForm((prev) => ({ ...prev, painterId: e.target.value }))}
                      required
                    />
                  </div>

                  {/* Valor */}
                  <div className="space-y-2">
                    <Label htmlFor="amount">Valor (R$) *</Label>
                    <Input
                      id="amount"
                      placeholder="0.00"
                      value={paymentForm.amount}
                      onChange={(e) => setPaymentForm((prev) => ({ ...prev, amount: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={logPaymentMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {logPaymentMutation.isPending ? "Registrando..." : "Registrar Pagamento"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tabela de Preços Tab */}
        <TabsContent value="prices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tabela de Preços</CardTitle>
              <CardDescription>Valor pago por peça pintada</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Peça</TableHead>
                      <TableHead className="text-right">Preço (R$)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paintingPrices.length > 0 ? (
                      paintingPrices.map((price) => (
                        <TableRow key={price.id}>
                          <TableCell className="font-medium">{price.piece}</TableCell>
                          <TableCell className="text-right">
                            {parseFloat(price.price).toLocaleString("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            })}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={2} className="text-center text-slate-400 py-8">
                          Nenhum preço registrado
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
