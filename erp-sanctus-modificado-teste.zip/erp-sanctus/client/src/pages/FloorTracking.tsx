import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Package } from "lucide-react";

export default function FloorTracking() {
  const { data: floorTracking = [] } = trpc.floorTracking.getAll.useQuery();

  const stages = [
    { key: "foundry", label: "Fundição", color: "bg-red-500" },
    { key: "cleaning", label: "Limpeza", color: "bg-orange-500" },
    { key: "finishing", label: "Acabamento", color: "bg-yellow-500" },
    { key: "mantle", label: "Manto", color: "bg-blue-500" },
    { key: "sprayPainting", label: "Pintura Pistola", color: "bg-purple-500" },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Chão de Fábrica</h1>
        <p className="text-slate-600">Rastreamento visual de peças em produção</p>
      </div>

      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Legenda de Etapas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {stages.map((stage) => (
              <div key={stage.key} className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded ${stage.color}`}></div>
                <span className="text-sm text-slate-600">{stage.label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Floor Tracking Grid */}
      <div className="space-y-4">
        {floorTracking.length > 0 ? (
          floorTracking.map((tracking) => (
            <Card key={tracking.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="grid grid-cols-1 md:grid-cols-6 gap-0">
                  {/* Peça Info */}
                  <div className="p-4 border-r border-slate-200 bg-slate-50">
                    <p className="text-xs text-slate-500 mb-1">Peça</p>
                    <p className="font-semibold text-slate-900">{tracking.piece}</p>
                    <p className="text-xs text-slate-500 mt-2">Código: {tracking.code}</p>
                  </div>

                  {/* Stages */}
                  {stages.map((stage) => {
                    const stageKey = stage.key as keyof typeof tracking;
                    const isCompleted = tracking[stageKey] === "completed";

                    return (
                      <div
                        key={stage.key}
                        className={`p-4 flex flex-col items-center justify-center border-r border-slate-200 ${
                          isCompleted ? "bg-green-50" : "bg-slate-50"
                        }`}
                      >
                        <div className="text-xs text-slate-500 mb-2 text-center">{stage.label}</div>
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm ${
                            isCompleted ? "bg-green-500" : stage.color
                          }`}
                        >
                          {isCompleted ? "✓" : "○"}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Package className="w-12 h-12 text-slate-300 mb-4" />
              <p className="text-slate-400 text-center">Nenhuma peça em rastreamento</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {stages.map((stage) => {
          const stageKey = stage.key as keyof typeof floorTracking[0];
          const completedCount = floorTracking.filter(
            (t) => t[stageKey] === "completed"
          ).length;

          return (
            <Card key={stage.key}>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm text-slate-600 mb-2">{stage.label}</p>
                  <p className="text-2xl font-bold text-slate-900">{completedCount}</p>
                  <p className="text-xs text-slate-500 mt-1">concluídas</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
