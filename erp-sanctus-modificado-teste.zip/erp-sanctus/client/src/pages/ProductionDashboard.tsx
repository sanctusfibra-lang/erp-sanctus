import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

export default function ProductionDashboard() {
  // Fetch production logs for different periods
  const today = new Date();
  const sevenDaysAgo = new Date(today);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const thirtyDaysAgo = new Date(today);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const { data: dailyLogs, isLoading: dailyLoading } = trpc.production.getLogsByDate.useQuery({ date: today });
  const { data: weeklyLogs, isLoading: weeklyLoading } = trpc.production.getLogsByDate.useQuery({ date: sevenDaysAgo });
  const { data: monthlyLogs, isLoading: monthlyLoading } = trpc.production.getLogsByDate.useQuery({ date: thirtyDaysAgo });

  // Calculate productivity metrics
  const calculateProductivity = (logs: any[] = []) => {
    if (logs.length === 0) return { totalProduced: 0, avgProductivity: 0, totalTime: 0 };
    
    const totalProduced = logs.reduce((sum, log) => sum + (log.quantity || 0), 0);
    const totalTime = logs.reduce((sum, log) => sum + (log.timeSpent || 0), 0);
    const avgProductivity = logs.length > 0 ? Math.round((totalProduced / logs.length) * 100) / 100 : 0;
    
    return { totalProduced, avgProductivity, totalTime };
  };

  const dailyMetrics = calculateProductivity(dailyLogs);
  const weeklyMetrics = calculateProductivity(weeklyLogs);
  const monthlyMetrics = calculateProductivity(monthlyLogs);

  // Group logs by collaborator for charts
  const groupByCollaborator = (logs: any[] = []) => {
    const grouped: Record<string, { name: string; quantity: number; timeSpent: number }> = {};
    
    logs.forEach((log) => {
      const name = log.name || "Desconhecido";
      if (!grouped[name]) {
        grouped[name] = { name, quantity: 0, timeSpent: 0 };
      }
      grouped[name].quantity += log.quantity || 0;
      grouped[name].timeSpent += log.timeSpent || 0;
    });
    
    return Object.values(grouped);
  };

  const dailyByUser = groupByCollaborator(dailyLogs);
  const weeklyByUser = groupByCollaborator(weeklyLogs);
  const monthlyByUser = groupByCollaborator(monthlyLogs);

  if (dailyLoading || weeklyLoading || monthlyLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          <p className="text-slate-600">Carregando dashboards de produção...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Sanctus 3.0 - Produção</h1>
        <p className="text-slate-600">Dashboards de produtividade diária, semanal e mensal</p>
      </div>

      {/* Tabs for different periods */}
      <Tabs defaultValue="daily" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="daily">Diário</TabsTrigger>
          <TabsTrigger value="weekly">Semanal</TabsTrigger>
          <TabsTrigger value="monthly">Mensal</TabsTrigger>
        </TabsList>

        {/* Daily Tab */}
        <TabsContent value="daily" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              title="Total Produzido"
              value={`${dailyMetrics.totalProduced} peças`}
              description="Quantidade total de peças"
            />
            <MetricCard
              title="Produtividade Média"
              value={`${dailyMetrics.avgProductivity}`}
              description="Peças por colaborador"
            />
            <MetricCard
              title="Tempo Total"
              value={`${Math.round(dailyMetrics.totalTime / 60)}h ${dailyMetrics.totalTime % 60}m`}
              description="Horas trabalhadas"
            />
          </div>

          {dailyByUser.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Produção por Colaborador (Hoje)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={dailyByUser}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="quantity" fill="#3b82f6" name="Peças Produzidas" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Weekly Tab */}
        <TabsContent value="weekly" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              title="Total Produzido"
              value={`${weeklyMetrics.totalProduced} peças`}
              description="Quantidade total de peças"
            />
            <MetricCard
              title="Produtividade Média"
              value={`${weeklyMetrics.avgProductivity}`}
              description="Peças por colaborador"
            />
            <MetricCard
              title="Tempo Total"
              value={`${Math.round(weeklyMetrics.totalTime / 60)}h ${weeklyMetrics.totalTime % 60}m`}
              description="Horas trabalhadas"
            />
          </div>

          {weeklyByUser.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Produção por Colaborador (Última Semana)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={weeklyByUser}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="quantity" fill="#06b6d4" name="Peças Produzidas" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Monthly Tab */}
        <TabsContent value="monthly" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              title="Total Produzido"
              value={`${monthlyMetrics.totalProduced} peças`}
              description="Quantidade total de peças"
            />
            <MetricCard
              title="Produtividade Média"
              value={`${monthlyMetrics.avgProductivity}`}
              description="Peças por colaborador"
            />
            <MetricCard
              title="Tempo Total"
              value={`${Math.round(monthlyMetrics.totalTime / 60)}h ${monthlyMetrics.totalTime % 60}m`}
              description="Horas trabalhadas"
            />
          </div>

          {monthlyByUser.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Produção por Colaborador (Último Mês)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={monthlyByUser}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="quantity" fill="#8b5cf6" name="Peças Produzidas" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Productivity Goals */}
      <Card>
        <CardHeader>
          <CardTitle>Meta de Disponibilidade</CardTitle>
          <CardDescription>Cálculo: 8h/dia × 5 dias/semana = 40h/semana</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm font-medium text-blue-900">Disponível Semanal</p>
              <p className="text-2xl font-bold text-blue-600 mt-2">40 horas</p>
              <p className="text-xs text-blue-700 mt-1">Meta padrão para cada colaborador</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm font-medium text-green-900">Semana Atual</p>
              <p className="text-2xl font-bold text-green-600 mt-2">{Math.round(weeklyMetrics.totalTime / 60)}h</p>
              <p className="text-xs text-green-700 mt-1">Horas trabalhadas na semana</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function MetricCard({
  title,
  value,
  description,
}: {
  title: string;
  value: string | number;
  description: string;
}) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-2">
          <p className="text-sm font-medium text-slate-600">{title}</p>
          <p className="text-3xl font-bold text-slate-900">{value}</p>
          <p className="text-xs text-slate-500">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}
