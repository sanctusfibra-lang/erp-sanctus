import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, ShoppingCart } from "lucide-react";

export default function Orders() {
  const [activeTab, setActiveTab] = useState("orders");
  const [orderForm, setOrderForm] = useState({
    clientId: "",
    description: "",
    quantity: "",
  });

  const [shipmentForm, setShipmentForm] = useState({
    orderId: "",
    nf: "",
    quantityShipped: "",
  });

  // Fetch data
  const { data: orders = [] } = trpc.orders.getAll.useQuery();
  const { data: clients = [] } = trpc.orders.getClients.useQuery();

  // Mutations
  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      toast.success("Pedido criado com sucesso!");
      setOrderForm({ clientId: "", description: "", quantity: "" });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const createShipmentMutation = trpc.orders.createShipment.useMutation({
    onSuccess: () => {
      toast.success("Envio registrado com sucesso!");
      setShipmentForm({ orderId: "", nf: "", quantityShipped: "" });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderForm.clientId || !orderForm.description || !orderForm.quantity) {
      toast.error("Preencha todos os campos");
      return;
    }

    createOrderMutation.mutate({
      clientId: parseInt(orderForm.clientId),
      description: orderForm.description,
      quantity: parseInt(orderForm.quantity),
    });
  };

  const handleShipmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shipmentForm.orderId || !shipmentForm.nf || !shipmentForm.quantityShipped) {
      toast.error("Preencha todos os campos");
      return;
    }

    createShipmentMutation.mutate({
      orderId: parseInt(shipmentForm.orderId),
      nf: shipmentForm.nf,
      quantityShipped: parseInt(shipmentForm.quantityShipped),
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "aberto":
        return <Badge className="bg-blue-100 text-blue-800">Aberto</Badge>;
      case "parcial":
        return <Badge className="bg-yellow-100 text-yellow-800">Parcial</Badge>;
      case "entregue":
        return <Badge className="bg-green-100 text-green-800">Entregue</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Pedidos</h1>
        <p className="text-slate-600">Gestão de pedidos de clientes</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="orders">Pedidos</TabsTrigger>
          <TabsTrigger value="shipments">Envios</TabsTrigger>
        </TabsList>

        {/* Pedidos Tab */}
        <TabsContent value="orders" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Criar Novo Pedido</CardTitle>
              <CardDescription>Registre um novo pedido de cliente</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleOrderSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Cliente */}
                  <div className="space-y-2">
                    <Label htmlFor="clientId">Cliente *</Label>
                    <select
                      id="clientId"
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={orderForm.clientId}
                      onChange={(e) => setOrderForm((prev) => ({ ...prev, clientId: e.target.value }))}
                      required
                    >
                      <option value="">Selecione um cliente</option>
                      {clients.map((client) => (
                        <option key={client.id} value={client.id}>
                          {client.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Quantidade */}
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantidade *</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      placeholder="0"
                      value={orderForm.quantity}
                      onChange={(e) => setOrderForm((prev) => ({ ...prev, quantity: e.target.value }))}
                      required
                    />
                  </div>

                  {/* Descrição */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="description">Descrição *</Label>
                    <Input
                      id="description"
                      placeholder="Descrição do pedido"
                      value={orderForm.description}
                      onChange={(e) => setOrderForm((prev) => ({ ...prev, description: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={createOrderMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {createOrderMutation.isPending ? "Criando..." : "Criar Pedido"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Lista de Pedidos */}
          <Card>
            <CardHeader>
              <CardTitle>Todos os Pedidos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Descrição</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.length > 0 ? (
                      orders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-medium">#{order.id}</TableCell>
                          <TableCell>
                            {clients.find((c) => c.id === order.clientId)?.name || "N/A"}
                          </TableCell>
                          <TableCell>{order.description}</TableCell>
                          <TableCell className="text-right">{order.quantity}</TableCell>
                          <TableCell>{getStatusBadge(order.status)}</TableCell>
                          <TableCell className="text-sm">
                            {new Date(order.createdAt).toLocaleDateString("pt-BR")}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-slate-400 py-8">
                          Nenhum pedido registrado
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Envios Tab */}
        <TabsContent value="shipments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Registrar Envio</CardTitle>
              <CardDescription>Registre um envio com Nota Fiscal</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleShipmentSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Pedido */}
                  <div className="space-y-2">
                    <Label htmlFor="orderId">Pedido *</Label>
                    <select
                      id="orderId"
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={shipmentForm.orderId}
                      onChange={(e) => setShipmentForm((prev) => ({ ...prev, orderId: e.target.value }))}
                      required
                    >
                      <option value="">Selecione um pedido</option>
                      {orders.map((order) => (
                        <option key={order.id} value={order.id}>
                          #{order.id} - {order.description}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* NF */}
                  <div className="space-y-2">
                    <Label htmlFor="nf">Nota Fiscal *</Label>
                    <Input
                      id="nf"
                      placeholder="Ex: NF-001"
                      value={shipmentForm.nf}
                      onChange={(e) => setShipmentForm((prev) => ({ ...prev, nf: e.target.value }))}
                      required
                    />
                  </div>

                  {/* Quantidade Enviada */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="quantityShipped">Quantidade Enviada *</Label>
                    <Input
                      id="quantityShipped"
                      type="number"
                      min="1"
                      placeholder="0"
                      value={shipmentForm.quantityShipped}
                      onChange={(e) => setShipmentForm((prev) => ({ ...prev, quantityShipped: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={createShipmentMutation.isPending}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  {createShipmentMutation.isPending ? "Registrando..." : "Registrar Envio"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
