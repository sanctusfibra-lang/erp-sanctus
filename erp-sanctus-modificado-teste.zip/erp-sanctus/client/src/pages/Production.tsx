import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, TrendingUp } from "lucide-react";

export default function Production() {
  const [formData, setFormData] = useState({
    piece: "",
    function: "",
    size: "",
    weight: "",
    quality: "OK",
    quantity: "1",
    code: "",
  });

  const [activeTab, setActiveTab] = useState("log");

  // Fetch production times
  const { data: productionTimes = [] } = trpc.production.getTimes.useQuery();

  // Fetch user's production logs
  const { data: myLogs = [] } = trpc.production.getMyLogs.useQuery({});

  // Mutations
  const logProductionMutation = trpc.production.logProduction.useMutation({
    onSuccess: () => {
      toast.success("Produção registrada com sucesso!");
      setFormData({
        piece: "",
        function: "",
        size: "",
        weight: "",
        quality: "OK",
        quantity: "1",
        code: "",
      });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.piece || !formData.function || !formData.size || !formData.code) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    logProductionMutation.mutate({
      piece: formData.piece,
      function: formData.function,
      size: formData.size,
      weight: formData.weight || undefined,
      quality: formData.quality,
      quantity: parseInt(formData.quantity),
      code: formData.code,
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Sanctus 3.0</h1>
        <p className="text-slate-600">Gestão de produção e produtividade</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="log">Lançamento</TabsTrigger>
          <TabsTrigger value="times">Tabela de Tempos</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
        </TabsList>

        {/* Lançamento Tab */}
        <TabsContent value="log" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Lançar Produção</CardTitle>
              <CardDescription>Registre uma nova produção realizada</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Peça */}
                  <div className="space-y-2">
                    <Label htmlFor="piece">Peça *</Label>
                    <Input
                      id="piece"
                      name="piece"
                      placeholder="Ex: ANJO ADORADOR"
                      value={formData.piece}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {/* Função */}
                  <div className="space-y-2">
                    <Label htmlFor="function">Função *</Label>
                    <Select value={formData.function} onValueChange={(value) => setFormData((prev) => ({ ...prev, function: value }))}>
                      <SelectTrigger id="function">
                        <SelectValue placeholder="Selecione a função" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Fundição">Fundição</SelectItem>
                        <SelectItem value="Limpeza">Limpeza</SelectItem>
                        <SelectItem value="Acabamento">Acabamento</SelectItem>
                        <SelectItem value="Manto">Manto</SelectItem>
                        <SelectItem value="Pintura Pistola">Pintura Pistola</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Tamanho */}
                  <div className="space-y-2">
                    <Label htmlFor="size">Tamanho *</Label>
                    <Input
                      id="size"
                      name="size"
                      placeholder="Ex: UNIDADE, 35"
                      value={formData.size}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {/* Peso */}
                  <div className="space-y-2">
                    <Label htmlFor="weight">Peso (kg)</Label>
                    <Input
                      id="weight"
                      name="weight"
                      placeholder="0.00"
                      value={formData.weight}
                      onChange={handleInputChange}
                    />
                  </div>

                  {/* Qualidade */}
                  <div className="space-y-2">
                    <Label htmlFor="quality">Qualidade</Label>
                    <Select value={formData.quality} onValueChange={(value) => setFormData((prev) => ({ ...prev, quality: value }))}>
                      <SelectTrigger id="quality">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="OK">OK</SelectItem>
                        <SelectItem value="Retrabalho">Retrabalho</SelectItem>
                        <SelectItem value="Defeito">Defeito</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Quantidade */}
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantidade *</Label>
                    <Input
                      id="quantity"
                      name="quantity"
                      type="number"
                      min="1"
                      value={formData.quantity}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  {/* Código */}
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="code">Código da Peça *</Label>
                    <Input
                      id="code"
                      name="code"
                      placeholder="Código único da peça"
                      value={formData.code}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={logProductionMutation.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {logProductionMutation.isPending ? "Registrando..." : "Registrar Produção"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tabela de Tempos Tab */}
        <TabsContent value="times" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tabela de Tempos</CardTitle>
              <CardDescription>Tempo padrão por função e peça</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Peça</TableHead>
                      <TableHead>Função</TableHead>
                      <TableHead>Tamanho</TableHead>
                      <TableHead className="text-right">Tempo (min)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {productionTimes.length > 0 ? (
                      productionTimes.map((time) => (
                        <TableRow key={time.id}>
                          <TableCell className="font-medium">{time.piece}</TableCell>
                          <TableCell>{time.function}</TableCell>
                          <TableCell>{time.size}</TableCell>
                          <TableCell className="text-right">{time.timeMinutes}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-slate-400 py-8">
                          Nenhum tempo registrado
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Histórico Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Meu Histórico</CardTitle>
              <CardDescription>Produções registradas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Peça</TableHead>
                      <TableHead>Função</TableHead>
                      <TableHead>Quantidade</TableHead>
                      <TableHead>Qualidade</TableHead>
                      <TableHead>Código</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {myLogs.length > 0 ? (
                      myLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="text-sm">
                            {new Date(log.loggedAt).toLocaleDateString("pt-BR")}
                          </TableCell>
                          <TableCell className="font-medium">{log.piece}</TableCell>
                          <TableCell>{log.function}</TableCell>
                          <TableCell>{log.quantity}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              log.quality === "OK" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                            }`}>
                              {log.quality}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm">{log.code}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-slate-400 py-8">
                          Nenhuma produção registrada
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
