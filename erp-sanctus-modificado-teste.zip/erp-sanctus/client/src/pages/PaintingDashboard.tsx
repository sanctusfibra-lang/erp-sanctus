import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

export default function PaintingDashboard() {
  // Fetch painting data
  const { data: movements, isLoading: movementsLoading } = trpc.painting.getMovementsByPainter.useQuery(
    { painterId: 0 },
    { enabled: false }
  );
  const { data: allMovements, isLoading: allMovementsLoading } = trpc.painting.getMovementsByPainter.useQuery(
    { painterId: 0 },
    { enabled: false }
  );
  const { data: prices, isLoading: pricesLoading } = trpc.painting.getPrices.useQuery();

  // Group movements by painter
  const groupMovementsByPainter = (movs: any[] = []) => {
    const grouped: Record<number, { painterId: number; movements: any[]; balance: number; totalValue: number }> = {};

    movs.forEach((mov) => {
      if (!grouped[mov.painterId]) {
        grouped[mov.painterId] = {
          painterId: mov.painterId,
          movements: [],
          balance: 0,
          totalValue: 0,
        };
      }
      grouped[mov.painterId].movements.push(mov);

      // Calculate balance (entrada = +, saida = -)
      const quantity = mov.type === "entrada" ? mov.quantity : -mov.quantity;
      grouped[mov.painterId].balance += quantity;

      // Calculate value based on price table
      const price = prices?.find((p: any) => p.piece === mov.piece);
      if (price) {
        const value = quantity * parseFloat(price.price);
        grouped[mov.painterId].totalValue += value;
      }
    });

    return Object.values(grouped);
  };

  if (movementsLoading || pricesLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          <p className="text-slate-600">Carregando dashboard de pintura...</p>
        </div>
      </div>
    );
  }

  // Mock data for demonstration (in production, fetch real data)
  const paintersSummary = [
    {
      painterId: 1,
      name: "Pintor 1",
      totalDelivered: 150,
      totalWithdrawn: 120,
      balance: 30,
      totalValue: 1500,
      payments: 1000,
      openValue: 500,
      balanceToPay: 0,
    },
    {
      painterId: 2,
      name: "Pintor 2",
      totalDelivered: 200,
      totalWithdrawn: 180,
      balance: 20,
      totalValue: 2000,
      payments: 1500,
      openValue: 500,
      balanceToPay: 0,
    },
    {
      painterId: 3,
      name: "Pintor 3",
      totalDelivered: 100,
      totalWithdrawn: 80,
      balance: 20,
      totalValue: 1000,
      payments: 600,
      openValue: 400,
      balanceToPay: 0,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Terceirização - Pintura</h1>
        <p className="text-slate-600">Dashboard consolidado de pintores e controle financeiro</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <SummaryCard
          title="Total Entregues"
          value={paintersSummary.reduce((sum, p) => sum + p.totalDelivered, 0)}
          description="Peças entregues para pintura"
          color="bg-blue-50 border-blue-200"
        />
        <SummaryCard
          title="Total Devolvidas"
          value={paintersSummary.reduce((sum, p) => sum + p.totalWithdrawn, 0)}
          description="Peças devolvidas"
          color="bg-green-50 border-green-200"
        />
        <SummaryCard
          title="Saldo em Posse"
          value={paintersSummary.reduce((sum, p) => sum + p.balance, 0)}
          description="Peças ainda com pintores"
          color="bg-orange-50 border-orange-200"
        />
        <SummaryCard
          title="Valor Total"
          value={`R$ ${paintersSummary.reduce((sum, p) => sum + p.totalValue, 0).toLocaleString("pt-BR")}`}
          description="Valor total de peças"
          color="bg-purple-50 border-purple-200"
        />
      </div>

      {/* Painters Table */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo por Pintor</CardTitle>
          <CardDescription>Controle de entregas, devoluções e situação financeira</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pintor</TableHead>
                  <TableHead className="text-right">Entregues</TableHead>
                  <TableHead className="text-right">Devolvidas</TableHead>
                  <TableHead className="text-right">Saldo</TableHead>
                  <TableHead className="text-right">Valor Total</TableHead>
                  <TableHead className="text-right">Pagamentos</TableHead>
                  <TableHead className="text-right">Valor em Aberto</TableHead>
                  <TableHead className="text-right">Saldo a Pagar</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paintersSummary.map((painter) => (
                  <TableRow key={painter.painterId} className="hover:bg-slate-50">
                    <TableCell className="font-medium">{painter.name}</TableCell>
                    <TableCell className="text-right">{painter.totalDelivered}</TableCell>
                    <TableCell className="text-right">{painter.totalWithdrawn}</TableCell>
                    <TableCell className="text-right">
                      <Badge variant="outline">{painter.balance}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      R$ {painter.totalValue.toLocaleString("pt-BR")}
                    </TableCell>
                    <TableCell className="text-right text-green-600 font-medium">
                      R$ {painter.payments.toLocaleString("pt-BR")}
                    </TableCell>
                    <TableCell className="text-right text-orange-600 font-medium">
                      R$ {painter.openValue.toLocaleString("pt-BR")}
                    </TableCell>
                    <TableCell className="text-right">
                      {painter.balanceToPay > 0 ? (
                        <Badge variant="destructive">R$ {painter.balanceToPay.toLocaleString("pt-BR")}</Badge>
                      ) : (
                        <Badge variant="secondary">Quitado</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Total Entregue</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-blue-600">
              R$ {paintersSummary.reduce((sum, p) => sum + p.totalValue, 0).toLocaleString("pt-BR")}
            </p>
            <p className="text-sm text-slate-600 mt-2">Valor total de peças entregues para pintura</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pagamentos Realizados</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">
              R$ {paintersSummary.reduce((sum, p) => sum + p.payments, 0).toLocaleString("pt-BR")}
            </p>
            <p className="text-sm text-slate-600 mt-2">Total pago aos pintores</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Saldo a Pagar</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-orange-600">
              R$ {paintersSummary.reduce((sum, p) => sum + p.openValue, 0).toLocaleString("pt-BR")}
            </p>
            <p className="text-sm text-slate-600 mt-2">Valor em aberto com pintores</p>
          </CardContent>
        </Card>
      </div>

      {/* Prices Table */}
      {prices && prices.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Tabela de Preços</CardTitle>
            <CardDescription>Valor pago por peça pintada</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Peça</TableHead>
                    <TableHead className="text-right">Valor (R$)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {prices.map((price: any) => (
                    <TableRow key={price.id}>
                      <TableCell className="font-medium">{price.piece}</TableCell>
                      <TableCell className="text-right">R$ {parseFloat(price.price).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function SummaryCard({
  title,
  value,
  description,
  color,
}: {
  title: string;
  value: string | number;
  description: string;
  color: string;
}) {
  return (
    <Card className={`border ${color}`}>
      <CardContent className="pt-6">
        <div className="space-y-2">
          <p className="text-sm font-medium text-slate-600">{title}</p>
          <p className="text-3xl font-bold text-slate-900">{value}</p>
          <p className="text-xs text-slate-500">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}
