import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, AlertTriangle } from "lucide-react";

export default function Stock() {
  const [activeTab, setActiveTab] = useState("materials");
  const [entryForm, setEntryForm] = useState({
    materialId: "",
    quantity: "",
  });

  const [movementForm, setMovementForm] = useState({
    materialId: "",
    quantity: "",
  });

  // Fetch data
  const { data: materials = [] } = trpc.stock.getMaterials.useQuery();
  const { data: purchaseOrders = [] } = trpc.stock.getPurchaseOrders.useQuery();
  const { data: myMovements = [] } = trpc.stock.getMyMovements.useQuery();

  // Mutations
  const logEntryMutation = trpc.stock.logEntry.useMutation({
    onSuccess: () => {
      toast.success("Entrada registrada!");
      setEntryForm({ materialId: "", quantity: "" });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const logMovementMutation = trpc.stock.logMovement.useMutation({
    onSuccess: () => {
      toast.success("Retirada registrada!");
      setMovementForm({ materialId: "", quantity: "" });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleEntrySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!entryForm.materialId || !entryForm.quantity) {
      toast.error("Preencha todos os campos");
      return;
    }

    logEntryMutation.mutate({
      materialId: parseInt(entryForm.materialId),
      quantity: parseInt(entryForm.quantity),
    });
  };

  const handleMovementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!movementForm.materialId || !movementForm.quantity) {
      toast.error("Preencha todos os campos");
      return;
    }

    logMovementMutation.mutate({
      materialId: parseInt(movementForm.materialId),
      quantity: parseInt(movementForm.quantity),
    });
  };

  const lowStockMaterials = materials.filter(
    (m) => m.currentStock <= m.minimumStock && m.trackable
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-gray-100 text-gray-800">Pendente</Badge>;
      case "pedido":
        return <Badge className="bg-blue-100 text-blue-800">Pedido</Badge>;
      case "recebido":
        return <Badge className="bg-green-100 text-green-800">Recebido</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Estoque & Compras</h1>
        <p className="text-slate-600">Controle de materiais e gestão de compras</p>
      </div>

      {/* Low Stock Alert */}
      {lowStockMaterials.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <AlertTriangle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-orange-900 mb-2">
                  {lowStockMaterials.length} material(is) com estoque baixo
                </h3>
                <ul className="text-sm text-orange-800 space-y-1">
                  {lowStockMaterials.map((m) => (
                    <li key={m.id}>
                      {m.name}: {m.currentStock} un. (mínimo: {m.minimumStock})
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="materials">Materiais</TabsTrigger>
          <TabsTrigger value="entry">Entradas</TabsTrigger>
          <TabsTrigger value="movements">Retiradas</TabsTrigger>
          <TabsTrigger value="purchase">Compras</TabsTrigger>
        </TabsList>

        {/* Materiais Tab */}
        <TabsContent value="materials" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Base de Estoque</CardTitle>
              <CardDescription>Materiais rastreados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Material</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead className="text-right">Estoque Atual</TableHead>
                      <TableHead className="text-right">Mínimo</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {materials.filter((m) => m.trackable).length > 0 ? (
                      materials
                        .filter((m) => m.trackable)
                        .map((material) => (
                          <TableRow key={material.id}>
                            <TableCell className="font-medium">{material.name}</TableCell>
                            <TableCell>{material.category}</TableCell>
                            <TableCell className="text-right">{material.currentStock}</TableCell>
                            <TableCell className="text-right">{material.minimumStock}</TableCell>
                            <TableCell>
                              {material.currentStock <= material.minimumStock ? (
                                <Badge className="bg-red-100 text-red-800">Baixo</Badge>
                              ) : (
                                <Badge className="bg-green-100 text-green-800">OK</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-slate-400 py-8">
                          Nenhum material registrado
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Entradas Tab */}
        <TabsContent value="entry" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Registrar Entrada</CardTitle>
              <CardDescription>Adicionar material ao estoque</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleEntrySubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Material */}
                  <div className="space-y-2">
                    <Label htmlFor="materialId">Material *</Label>
                    <select
                      id="materialId"
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={entryForm.materialId}
                      onChange={(e) => setEntryForm((prev) => ({ ...prev, materialId: e.target.value }))}
                      required
                    >
                      <option value="">Selecione um material</option>
                      {materials
                        .filter((m) => m.trackable)
                        .map((material) => (
                          <option key={material.id} value={material.id}>
                            {material.name}
                          </option>
                        ))}
                    </select>
                  </div>

                  {/* Quantidade */}
                  <div className="space-y-2">
                    <Label htmlFor="entryQuantity">Quantidade *</Label>
                    <Input
                      id="entryQuantity"
                      type="number"
                      min="1"
                      placeholder="0"
                      value={entryForm.quantity}
                      onChange={(e) => setEntryForm((prev) => ({ ...prev, quantity: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={logEntryMutation.isPending}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {logEntryMutation.isPending ? "Registrando..." : "Registrar Entrada"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Retiradas Tab */}
        <TabsContent value="movements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Registrar Retirada</CardTitle>
              <CardDescription>Remover material do estoque</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleMovementSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Material */}
                  <div className="space-y-2">
                    <Label htmlFor="movementMaterialId">Material *</Label>
                    <select
                      id="movementMaterialId"
                      className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      value={movementForm.materialId}
                      onChange={(e) => setMovementForm((prev) => ({ ...prev, materialId: e.target.value }))}
                      required
                    >
                      <option value="">Selecione um material</option>
                      {materials
                        .filter((m) => m.trackable)
                        .map((material) => (
                          <option key={material.id} value={material.id}>
                            {material.name}
                          </option>
                        ))}
                    </select>
                  </div>

                  {/* Quantidade */}
                  <div className="space-y-2">
                    <Label htmlFor="movementQuantity">Quantidade *</Label>
                    <Input
                      id="movementQuantity"
                      type="number"
                      min="1"
                      placeholder="0"
                      value={movementForm.quantity}
                      onChange={(e) => setMovementForm((prev) => ({ ...prev, quantity: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={logMovementMutation.isPending}
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {logMovementMutation.isPending ? "Registrando..." : "Registrar Retirada"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Histórico de Retiradas */}
          <Card>
            <CardHeader>
              <CardTitle>Minhas Retiradas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Material</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {myMovements.length > 0 ? (
                      myMovements.map((mov) => (
                        <TableRow key={mov.id}>
                          <TableCell className="text-sm">
                            {new Date(mov.movementDate).toLocaleDateString("pt-BR")}
                          </TableCell>
                          <TableCell>
                            {materials.find((m) => m.id === mov.materialId)?.name || "N/A"}
                          </TableCell>
                          <TableCell className="text-right">{mov.quantity}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-slate-400 py-8">
                          Nenhuma retirada registrada
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Compras Tab */}
        <TabsContent value="purchase" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Compras</CardTitle>
              <CardDescription>Pedidos de compra gerados automaticamente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Categoria</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Data</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {purchaseOrders.length > 0 ? (
                      purchaseOrders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell>{order.category}</TableCell>
                          <TableCell className="font-medium">{order.itemName}</TableCell>
                          <TableCell className="text-right">{order.quantityToPurchase}</TableCell>
                          <TableCell>{getStatusBadge(order.status)}</TableCell>
                          <TableCell className="text-sm">
                            {new Date(order.generatedAt).toLocaleDateString("pt-BR")}
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-slate-400 py-8">
                          Nenhum pedido de compra
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
