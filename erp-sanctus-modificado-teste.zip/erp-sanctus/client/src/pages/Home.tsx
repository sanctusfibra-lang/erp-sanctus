import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import {
  Factory,
  Truck,
  ShoppingCart,
  Package,
  BarChart3,
  Users,
  ArrowRight,
  Zap,
} from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="animate-pulse text-white">Carregando...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        {/* Header */}
        <header className="border-b border-slate-700/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Factory className="w-8 h-8 text-blue-400" />
              <h1 className="text-2xl font-bold text-white">ERP Sanctus</h1>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <main className="flex-1 flex flex-col items-center justify-center px-4 py-20">
          <div className="max-w-2xl text-center space-y-8">
            <div className="space-y-4">
              <h2 className="text-5xl font-bold text-white tracking-tight">
                Sistema de Gestão Industrial
              </h2>
              <p className="text-xl text-slate-300">
                Centralize produção, rastreamento de peças, terceirização, pedidos e compras em uma única plataforma elegante e intuitiva.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => {
                  window.location.href = getLoginUrl();
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all"
              >
                Entrar no Sistema
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-16">
              <FeatureCard
                icon={<Factory className="w-6 h-6" />}
                title="Sanctus 3.0"
                description="Gestão completa de produção com dashboards de produtividade"
              />
              <FeatureCard
                icon={<Truck className="w-6 h-6" />}
                title="Terceirização"
                description="Controle de pintura terceirizada e financeiro integrado"
              />
              <FeatureCard
                icon={<Package className="w-6 h-6" />}
                title="Rastreamento"
                description="Mapa visual de peças no chão de fábrica em tempo real"
              />
              <FeatureCard
                icon={<ShoppingCart className="w-6 h-6" />}
                title="Pedidos & Compras"
                description="Gestão de pedidos de clientes e estoque centralizado"
              />
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-700/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-slate-400">
            <p>© 2026 ERP Sanctus. Sistema de Gestão Industrial.</p>
          </div>
        </footer>
      </div>
    );
  }

  // Authenticated user - show dashboard access
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Factory className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-slate-900">ERP Sanctus</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-600">Bem-vindo, {user?.name || "Usuário"}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="space-y-8">
          {/* Welcome Section */}
          <div className="space-y-2">
            <h2 className="text-3xl font-bold text-slate-900">Dashboard</h2>
            <p className="text-slate-600">Acesse os módulos de gestão industrial</p>
          </div>

          {/* Modules Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ModuleCard
              icon={<BarChart3 className="w-8 h-8" />}
              title="Dashboard Geral"
              description="Visão consolidada de KPIs e métricas principais"
              onClick={() => navigate("/dashboard")}
              color="from-blue-500 to-blue-600"
            />

            <ModuleCard
              icon={<Factory className="w-8 h-8" />}
              title="Sanctus 3.0"
              description="Gestão de produção e produtividade"
              onClick={() => navigate("/production")}
              color="from-purple-500 to-purple-600"
            />

            <ModuleCard
              icon={<Package className="w-8 h-8" />}
              title="Chão de Fábrica"
              description="Rastreamento visual de peças em produção"
              onClick={() => navigate("/floor-tracking")}
              color="from-orange-500 to-orange-600"
            />

            <ModuleCard
              icon={<Truck className="w-8 h-8" />}
              title="Terceirização"
              description="Gestão de pintura e financeiro"
              onClick={() => navigate("/painting")}
              color="from-green-500 to-green-600"
            />

            <ModuleCard
              icon={<ShoppingCart className="w-8 h-8" />}
              title="Pedidos"
              description="Gestão de pedidos de clientes"
              onClick={() => navigate("/orders")}
              color="from-red-500 to-red-600"
            />

            <ModuleCard
              icon={<Zap className="w-8 h-8" />}
              title="Estoque"
              description="Controle de materiais e compras"
              onClick={() => navigate("/stock")}
              color="from-indigo-500 to-indigo-600"
            />
          </div>

          {/* Profile Section */}
          <div className="mt-12 pt-8 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Meu Perfil</h3>
                <p className="text-sm text-slate-600">Visualize seu histórico e dados pessoais</p>
              </div>
              <Button
                onClick={() => navigate("/profile")}
                variant="outline"
              >
                Acessar Perfil
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 text-left hover:border-slate-600 transition-colors">
      <div className="flex items-start gap-3">
        <div className="text-blue-400 mt-1">{icon}</div>
        <div>
          <h3 className="font-semibold text-white">{title}</h3>
          <p className="text-sm text-slate-400">{description}</p>
        </div>
      </div>
    </div>
  );
}

function ModuleCard({
  icon,
  title,
  description,
  onClick,
  color,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
  color: string;
}) {
  return (
    <Card
      onClick={onClick}
      className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 border-0"
    >
      <CardHeader>
        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${color} text-white flex items-center justify-center mb-4`}>
          {icon}
        </div>
        <CardTitle className="text-lg">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Button variant="ghost" size="sm" className="w-full justify-start">
          Acessar
          <ArrowRight className="w-4 h-4 ml-auto" />
        </Button>
      </CardContent>
    </Card>
  );
}
