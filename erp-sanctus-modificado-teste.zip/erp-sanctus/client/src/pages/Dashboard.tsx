import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, AlertCircle, Package, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Dashboard() {
  // Fetch real KPIs from API
  const { data: kpis, isLoading } = trpc.dashboard.getKPIs.useQuery();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          <p className="text-slate-600">Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-slate-900">Dashboard Geral</h1>
        <p className="text-slate-600">Visão consolidada de KPIs e métricas principais</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          title="Produtividade Semanal"
          value={`${kpis?.weeklyProductivity || 0}%`}
          description="Média de produtividade"
          icon={<TrendingUp className="w-8 h-8 text-green-600" />}
          color="bg-green-50 border-green-200"
        />

        <KPICard
          title="Peças em Pintura"
          value={kpis?.openPaintingPieces || 0}
          description="Aguardando conclusão"
          icon={<Package className="w-8 h-8 text-blue-600" />}
          color="bg-blue-50 border-blue-200"
        />

        <KPICard
          title="Pedidos Pendentes"
          value={kpis?.pendingOrders || 0}
          description="Não entregues"
          icon={<BarChart3 className="w-8 h-8 text-purple-600" />}
          color="bg-purple-50 border-purple-200"
        />

        <KPICard
          title="Materiais Baixos"
          value={kpis?.lowStockMaterials || 0}
          description="Abaixo do mínimo"
          icon={<AlertCircle className="w-8 h-8 text-orange-600" />}
          color="bg-orange-50 border-orange-200"
        />
      </div>

      {/* Summary Section */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo Operacional</CardTitle>
          <CardDescription>Status atual do sistema</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-slate-600">Produtividade Semanal</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{kpis?.weeklyProductivity || 0}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600 opacity-50" />
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-slate-600">Peças em Processamento</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{kpis?.openPaintingPieces || 0}</p>
              </div>
              <Package className="w-8 h-8 text-blue-600 opacity-50" />
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-slate-600">Pedidos Aguardando Entrega</p>
                <p className="text-2xl font-bold text-slate-900 mt-1">{kpis?.pendingOrders || 0}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-purple-600 opacity-50" />
            </div>

            {(kpis?.lowStockMaterials || 0) > 0 && (
              <div className="flex items-center justify-between p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-orange-700">Materiais com Estoque Baixo</p>
                  <p className="text-2xl font-bold text-orange-900 mt-1">{kpis?.lowStockMaterials || 0}</p>
                </div>
                <AlertCircle className="w-8 h-8 text-orange-600 opacity-50" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Ações Rápidas</CardTitle>
          <CardDescription>Acesse os módulos principais</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <QuickActionItem
              title="Registrar Produção"
              description="Lançar nova produção realizada"
              href="/production"
            />
            <QuickActionItem
              title="Rastrear Peças"
              description="Visualizar status das peças no chão"
              href="/floor-tracking"
            />
            <QuickActionItem
              title="Gerenciar Pedidos"
              description="Criar e acompanhar pedidos"
              href="/orders"
            />
            <QuickActionItem
              title="Controlar Estoque"
              description="Registrar entradas e retiradas"
              href="/stock"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function KPICard({
  title,
  value,
  description,
  icon,
  color,
}: {
  title: string;
  value: string | number;
  description: string;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <Card className={`border ${color}`}>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-600">{title}</p>
            <p className="text-3xl font-bold text-slate-900">{value}</p>
            <p className="text-xs text-slate-500">{description}</p>
          </div>
          <div className="opacity-80">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function QuickActionItem({
  title,
  description,
  href,
}: {
  title: string;
  description: string;
  href: string;
}) {
  return (
    <a
      href={href}
      className="p-4 border border-slate-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all cursor-pointer group"
    >
      <h3 className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">{title}</h3>
      <p className="text-sm text-slate-600 mt-1">{description}</p>
    </a>
  );
}
