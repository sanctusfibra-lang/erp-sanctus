import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import DashboardLayout from "@/components/DashboardLayout";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Production from "./pages/Production";
import ProductionDashboard from "./pages/ProductionDashboard";
import FloorTracking from "./pages/FloorTracking";
import Painting from "./pages/Painting";
import PaintingDashboard from "./pages/PaintingDashboard";
import Orders from "./pages/Orders";
import Stock from "./pages/Stock";
import Profile from "./pages/Profile";
import Cadastros from "./pages/Cadastros";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      
      {/* Dashboard routes - wrapped with DashboardLayout */}
      <Route path={"/dashboard"}>
        {() => (
          <DashboardLayout>
            <Dashboard />
          </DashboardLayout>
        )}
      </Route>

      {/* Production (Sanctus 3.0) */}
      <Route path={"/production"}>
        {() => (
          <DashboardLayout>
            <Production />
          </DashboardLayout>
        )}
      </Route>

      {/* Production Dashboard */}
      <Route path={"/production-dashboard"}>
        {() => (
          <DashboardLayout>
            <ProductionDashboard />
          </DashboardLayout>
        )}
      </Route>

      {/* Floor Tracking (Chão) */}
      <Route path={"/floor-tracking"}>
        {() => (
          <DashboardLayout>
            <FloorTracking />
          </DashboardLayout>
        )}
      </Route>

      {/* Painting (Terceirização) */}
      <Route path={"/painting"}>
        {() => (
          <DashboardLayout>
            <Painting />
          </DashboardLayout>
        )}
      </Route>

      {/* Painting Dashboard */}
      <Route path={"/painting-dashboard"}>
        {() => (
          <DashboardLayout>
            <PaintingDashboard />
          </DashboardLayout>
        )}
      </Route>

      {/* Orders */}
      <Route path={"/orders"}>
        {() => (
          <DashboardLayout>
            <Orders />
          </DashboardLayout>
        )}
      </Route>

      {/* Stock/Materials */}
      <Route path={"/stock"}>
        {() => (
          <DashboardLayout>
            <Stock />
          </DashboardLayout>
        )}
      </Route>


      {/* Cadastros */}
      <Route path={"/cadastros"}>
        {() => (
          <DashboardLayout>
            <Cadastros />
          </DashboardLayout>
        )}
      </Route>


      {/* User Profile */}
      <Route path={"/profile"}>
        {() => (
          <DashboardLayout>
            <Profile />
          </DashboardLayout>
        )}
      </Route>

      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
